import { mongo } from "./CMongodb"
import { Response, Request } from "express"


export function login(request: Request, response: Response) {
    let qury = request.query()
    console.log(qury)
    response.end('login')
}

export function insertDoc(request: Request, response: Response) {
    mongo.insertDoc('chat', {name: 'test', password: '123'})
    let qury = request.query()
    console.log(qury)
    response.end('insertDoc')
}

export function find(request: Request, response: Response) {
    let ret = mongo.find('chat', {name: 'test'})
    console.log(ret)
    let qury = request.query()
    console.log(qury)
    response.end('find')
}