
import WSRouter from './CWSRouter'

let wsRouter = new WSRouter(8081)
wsRouter.listen()